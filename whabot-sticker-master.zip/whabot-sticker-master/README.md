# whabot-sticker
repo hasil video bikin bot sticker
